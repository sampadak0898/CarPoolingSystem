# DriveMe_Car_Pooling_Platform
Description: DriveMe is carpooling app that helps users to share ridesamongst travellers that travel on the same route. This system has 2 actors one being the Offeror who offers thecar ride and one being the Requester who has requested for the ride. DriveMe is a portal that helps a user to input his travel route and find a suitable ride along the way. It was the team project. 
a.	I did the role of both front-end as well as back-end developer.
b.	We used Spring Boot Framework and MySQL database
c.	I was involved in developing front-end using BOOTSTRAP framework



## Team Members:
1) Danish Khan
2) Atharva Joglekar
3) Dhaval Bhanderi
4) Mansi Mehta
